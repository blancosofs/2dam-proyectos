package ui;

public class Main {


	public static void main(String[] args) {
		/**
		 * -------------------------------------------------------------
		 * Nombre: Sofía Blanco Calsina
		 * Asignatura: Acceso a Datos Conexion a la BBDD
		 * Entrega: Recuperacion Práctica Final – Tema 2
		 * Profesora: Beatriz
		 * -------------------------------------------------------------
		 * EJECUCIÓN Y PRUEBA:
		 * 
		 * Inserts implementados:
		 * 20 juguetes 
		 * 20 empleados 
		 * 5 stands (A,B,C,D,E)
		 * 4 Zonas (Luna, Elisa, Mario, Rafa)
		 * Los 20 juguetes tienen un stock
		 * 
		 *
		 */
		
		
		JugueteriaBlanco.main(args);
	}

}
