package ui;

public class Main {

	public static void main(String[] args) {
		/**
		 * -------------------------------------------------------------- 
		 * Nombre: Sofía Blanco Calsina 
		 * Asignatura: Acceso a Datos Ficheros (Java I/O) 
		 * Entrega: Recuperacion Práctica Final – Tema 1 
		 * Profesora: Beatriz
		 * --------------------------------------------------------------
		 * 
		 * Pocas mejoras. 
		 * 
		 */

		ViveroBlanco.main(args);
	}

}
